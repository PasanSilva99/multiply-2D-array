﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Multiplying_darray
{
    class Program
    {
        static void comments()
        {
            //int[] c11 = new int[3];
            //array1[3,2]
            //array2[2,3]
            // array1[0,0]*array2[0,0]
            // array1[1,0]*array2[0,1]
            // array1[2,0]*array2[0,2]

            /* f=0  s=0    s=0  f=0
             * f=1  s=0    s=0  f=1
             * f=2  s=0    s=0  f=2
             * 
             * s=0
             * f<3
             * 
             * for(int f=0;f<3;f++)
             * {
             *   int s=0;
             *   ic11 = ic11+(array1[f,s]*array2[s,f]);
             *   ic12 = ic12+(array1[f,s]*array2[s+1,f]);
             *   ic21 = ic21+(array1[f,s+1]*array2[s,f]);
             *   ic22 = ic22+(array1[f,s+1]*array2[s+1,f]);
             *   
             * }
             * 
             */

            //int[] c12 = new int[3];
            // array1[0,0]*array2[1,0]
            // array1[1,0]*array2[1,1]
            // array1[2,0]*array2[1,2]

            //int[] c21 = new int[3];
            // array1[0,1]*array2[0,0]
            // array1[1,1]*array2[0,1]
            // array1[2,1]*array2[0,2]

            //int[] c22 = new int[3];
            // array1[0,1]*array2[1,0]
            // array1[1,1]*array2[1,1]
            // array1[2,1]*array2[1,2]

        }
        static void Main(string[] args)
        {
            int[,] array1 = new int[3, 2];
            int[,] array2 = new int[2, 3];
            int[,] totarray = new int[2, 2];
            int ic11=0, 
                ic12=0, 
                ic21=0, 
                ic22=0;
        

            for (int i = 0; i<3;i++) //i th row j th column
            {
                Console.WriteLine($"Recording {i + 1} Row on Array 1");

                for(int j = 0; j<2;j++)
                {
                    Console.Write($"Enter the value {j + 1} on column {i + 1} : ");
                    array1[i, j] = int.Parse(Console.ReadLine());

                }

                Console.Write("\n--------------------------------\n");
            }

            Console.WriteLine(":-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:");

            for (int i = 0; i < 2; i++) //i th row j th column
            {
                Console.WriteLine($"Recording {i + 1} Row on Array 2");

                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{j + 1} on column {i + 1} : ");
                    array2[i, j] = int.Parse(Console.ReadLine());
                    
                }

                Console.Write("\n");
            }

            ///
            ///Display the arrays
            ///

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Array 1");
            for (int i = 0; i < 3; i++) //i th row j th column
            {
                for (int j = 0; j < 2; j++)
                {
                    Console.Write($"{array1[i,j]}");
                    Console.Write("\t");

                }

                Console.Write("\n");
            }
            Console.ResetColor();
            Console.WriteLine(":-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Array 2");
            for (int i = 0; i < 2; i++) //i th row j th column
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{array2[i,j]}");
                    Console.Write("\t");

                }

                Console.Write("\n");
            }
            Console.ResetColor();
            Console.WriteLine(":-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:");
            Console.WriteLine(":-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:");

            ///
            /// Calculation
            ///
            for (int f = 0; f < 3; f++)
            {
                int s = 0;
                ic11 = ic11 + (array1[f, s] * array2[s, f]);
                ic12 = ic12 + (array1[f, s] * array2[s + 1, f]);
                ic21 = ic21 + (array1[f, s + 1] * array2[s, f]);
                ic22 = ic22 + (array1[f, s + 1] * array2[s + 1, f]);
                
            }

           
            ///
            ///Assigning the values to the total array
            ///
            totarray[0, 0] = ic11;
            totarray[0, 1] = ic12;
            totarray[1, 0] = ic21;
            totarray[1, 1] = ic22;


            ///
            ///Display the total array
            ///
            for (int i = 0; i < 2; i++) //i th row j th column
            {
                for (int j = 0; j < 2; j++)
                {
                    Console.Write($"{totarray[i,j]}");
                    Console.Write("\t");
                }

                Console.Write("\n");
            }
            Console.ReadLine();
        }
    }
}
